package guia9.Ex2.MainAhorcado;

import guia9.Ex2.ServicioAhorcado.ServicioAhorcado;

public class MainAhorcado {

    public static void main(String[] args) {
        
        ServicioAhorcado A = new ServicioAhorcado();
        
        A.juego();
    }
    
}
